#!/bin/bash
systemctl start httpd.service
systemctl enable httpd.service